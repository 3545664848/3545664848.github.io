---
title: Sublime Text 之常用快捷键
date: 2018-08-22 15:13:34
categories: sublime
tags:

copyright:
---


## Sublime Text简介：


Sublime Text是一款跨平台代码编辑器（Code Editor）， 具有华丽的用户界面和强大的功能
是由程序员Jon Skinner于2008年1月份所开发出来，它最初被设计为一个具有丰富扩展功能的Vim
从最初的Sublime Text 1.0，到现在的Sublime Text 3.0，Sublime Text从一个不知名的编辑器演变到现在几乎是各平台首选的GUI编辑器


>工欲善其事，必先利其器
>下面是一些比较常用的快捷键

## 快捷键列表（Shortcuts Cheatsheet）

### 通用（General）

* ``↑↓←→``：上下左右移动光标
* ``Alt``： 调出菜单
* ``Ctrl + Shift + P``： 调出命令板（Command Palette）
* ``Ctrl + ` ``：调出控制台


### 编辑（Editing）

* ``Ctrl + Enter``： 在当前行下面新增一行然后跳至该行
* ``Ctrl + Shift + Enter``：在当前行上面增加一行并跳至该行
* ``Ctrl + ←/→``：进行逐词移动
* ``Ctrl + Shift + ←/→``：进行逐词选择
* ``Ctrl + ↑/↓``：移动当前显示区域
* ``Ctrl + Shift + ↑/↓``： 移动当前行


### 选择（Selecting）

* ``Ctrl + D``：选择当前光标所在的词并高亮该词所有出现的位置，再次 Ctrl + D 选择该词出现的下一个位置，在多重选词的过程中，使用 Ctrl + K 进行跳过，使用 Ctrl + U 进行回退，使用 Esc 退出多重编辑
* ``Ctrl + Shift + L``：将当前选中区域打散
* ``Ctrl + J``：把当前选中区域合并为一行
* ``Ctrl + M``：在起始括号和结尾括号间切换
* ``Ctrl + Shift + M``：快速选择括号间的内容
* ``Ctrl + Shift + J``：快速选择同缩进的内容
* ``Ctrl + Shift + Space``：快速选择当前作用域（Scope）的内容


### 查找&替换（Finding&Replacing）

* ``F3``：跳至当前关键字下一个位置
* ``Shift + F3``：跳到当前关键字上一个位置
* ``Alt + F3``：选中当前关键字出现的所有位置
* ``Ctrl + F/H``：进行标准查找/替换，之后：
	- ``Alt + C``：切换大小写敏感（Case-sensitive）模式
	- ``Alt + W``：切换整字匹配（Whole matching）模式
	- ``Alt + R``：切换正则匹配（Regex matching）模式
	- ``Ctrl + Shift + H``：替换当前关键字
	- ``Ctrl + Alt + Enter``：替换所有关键字匹配
* ``Ctrl + Shift + F``：多文件搜索&替换


### 跳转（Jumping）

* ``Ctrl + P``：跳转到指定文件，输入文件名后可以：
	+ ``@`` 符号跳转：输入 ``@symbol`` 跳转到 ``symbol`` 符号所在的位置
	+ ``#`` 关键字跳转：输入 ``#keyword`` 跳转到 ``keyword`` 所在的位置
	+ ``:`` 行号跳转：输入 ``:12`` 跳转到文件的第12行。
* ``Ctrl + R``：跳转到指定符号
* ``Ctrl + G``：跳转到指定行号


### 屏幕（Screen）

* ``F11``：切换普通全屏
* ``Shift + F11``：切换无干扰全屏
* ``Alt + Shift + 2``：进行左右分屏
* ``Alt + Shift + 8``：进行上下分屏
* ``Alt + Shift + 5``：进行上下左右分屏

> 分屏之后，使用 ``Ctrl + 数字键`` 跳转到指定屏，使用 ``Ctrl + >Shift + 数字键`` 将当前屏移动到指定屏



## 附表（精华版）

* ``Ctrl+Shift+P``：打开命令面板
* ``Ctrl+P``：搜索项目中的文件
* ``Ctrl+G``：跳转到第几行
* ``Ctrl+W``：关闭当前打开文件
* ``Ctrl+Shift+W``：关闭所有打开文件
* ``Ctrl+Shift+V``：粘贴并格式化
* ``Ctrl+D``：选择单词，重复可增加选择下一个相同的单词
* ``Ctrl+L``：选择行，重复可依次增加选择下一行
* ``Ctrl+Shift+L``：选择多行
* ``Ctrl+Shift+Enter``：在当前行前插入新行
* ``Ctrl+X``：删除当前行
* ``Ctrl+M``：跳转到对应括号
* ``Ctrl+U``：软撤销，撤销光标位置
* ``Ctrl+J``：选择标签内容
* ``Ctrl+F``：查找内容
* ``Ctrl+Shift+F``：查找并替换
* ``Ctrl+H``：替换
* ``Ctrl+R``：前往 method
* ``Ctrl+N``：新建窗口
* ``Ctrl+K+B``：开关侧栏
* ``Ctrl+Shift+M``：选中当前括号内容，重复可选着括号本身
* ``Ctrl+F2``：设置/删除标记
* ``Ctrl+/``：注释当前行
* ``Ctrl+Shift+/``：当前位置插入注释
* ``Ctrl+Alt+/``：块注释，并Focus到首行，写注释说明用的
* ``Ctrl+Shift+A``：选择当前标签前后，修改标签用的
* ``F11``：全屏
* ``Shift+F11``：全屏免打扰模式，只编辑当前文件
* ``Alt+F3``：选择所有相同的词
* ``Alt+.``：闭合标签
* ``Alt+Shift+数字``：分屏显示
* ``Alt+数字``：切换打开第N个文件
* ``Shift+右键拖动``：光标多步，用来更改或插入列内容
* ``按Ctrl``，依次点击或选取，可需要编辑的多个位置
* ``按Ctrl+Shift+上下键``，可替换行