---
title: Scrapy 之安装教程
date: 2018-08-25 18:49:59
tags:
    - 教程

categories: scrapy
copyright:
---


 Scrapy 是一个功能十分强大的爬虫框架，用于抓取web站点并从页面中提取结构化的数据。Scrapy用途广泛，本篇教程主要是介绍在python3X中安装的方法及注意事项，就不对scrapy做详细描述了。
Scrapy作为一个优秀的爬虫框架，本身是基于一些库文件进行开发的，由于Scrapy这种高级的特性，这就注定了它需要依赖许多其他的库文件。所以在安装scrapy框架之前，首先要确定安装了它所依赖的环境。(我最开始安装scrapy时并不知道这些，结果各种花式报错，让我一脸懵逼)

---

**基本的依赖环境：**

>wheel
>lxml
>Twisted
>pyOpenSSL
>PyWin32

---

**注意：**
* 安装依赖库之前先确定一下自己的python版本号和操作系统位数。
* 由于python3X版本比较多,请根据自己对应的版本下载库文件
* python2请勿略本以下内容，可以直接安装scrapy
* 其实通过Anaconda方式安装python 就不会出现这么多问题了
* 如果安装过程中出现报错提示说pip版本太低，先升级pip：
``
python -m pip install --upgrade pip
``



**1.安装wheel**

直接命令行输入
```
pip3 install wheel
```

如果没有任何报错，则说明安装成功，如果出现以下内容
```
Requirement already satisfied：
```
则说明早就已经安装好了

如果出现报错，比如提示缺少 libxml2 库等信息，可以采用 wheel 方式安装。移步以下链接：
https://www.lfd.uci.edu/~gohlke/pythonlibs/#lxml

下载对应的 wheel 文 件，找到与自己的 Python 版本和系统对应的 lxml 版本
例如 Windows 64 位、Python 3.7，就选择 lxml‑4.2.4‑cp37‑cp37m‑win_amd64.whl ，将其下载到本地
然后命令行切换到.whl文件所在的目录，执行以下命令：
```
pip3 install lxml‑4.2.4‑cp37‑cp37m‑win_amd64.whl
```



**2.安装Twisted**

安装Twisted和之前的wheel安装方试大同小异，注意一定要选择相对应的版本下载
https://www.lfd.uci.edu/~gohlke/pythonlibs/#twisted

然后命令行切换到文件所在路径，执行命令：
```
pip3 install Twisted‑18.7.0‑cp37‑cp37m‑win_amd64.whl
```

不想命令行切换路径的话，可以使用绝对路径，形如：
```
pip3 install C:\Users\song\Downloads\Twisted-18.7.0-cp37-cp37m-win_amd64.whl
```



**3.安装pyOpenSSL**

直接在官网下载  pyOpenSSL-18.0.0-py2.py3-none-any.whl 文件
https://pypi.org/project/pyOpenSSL/#downloads

然后命令行切换到文件所在路径，执行命令：
```
pip3 install pyOpenSSL-18.0.0-py2.py3-none-any.whl
```


**4.安装pywin32**

首先还是找到对应版本下载，然后直接运行.exe文件安装就好了
https://sourceforge.net/projects/pywin32/files/pywin32/Build%20221/

安装相应的库文件后应该就可以安装scrapy框架了，执行命令：
```
pip install scrapy
```

测试一下：
```
scrapy -h
```

安装完成之后 就可以愉快的开始第一个爬虫项目了：
```
scrapy startproject firstscrapy
```


**值得注意的是，在运行爬虫的时候发现又报错了，形如：**
```
File”c:\users\name\appdata\locall\programs\python37\lib\site-packages\twisted\conch\manhole.py”, line 12,in from twisted.conch import manhole, telnet
def write(self, data, async=false): 
File”c:\users\name\appdata\locall\programs\python37\lib\site-packages\twisted\conch\manhole.py”, line 154 
def write(self, data, async=false):
```


**出现原因：**

这是由于python3.7中将async设为关键字，而不能作为变量名使用

**解决方案：**

1. 根据报错提示进入manhole.py将async全改成async1就阔以了
2. 直接安装python3.6亦可


如果安装过程还遇到其他问题，可以参考以下链接：
https://www.jb51.net/article/128885.htm
https://blog.csdn.net/qy20115549/article/details/52528896#%E5%AE%89%E8%A3%85pywin32
https://docs.scrapy.org/en/latest/intro/install.html#intro-install-platform-notes
